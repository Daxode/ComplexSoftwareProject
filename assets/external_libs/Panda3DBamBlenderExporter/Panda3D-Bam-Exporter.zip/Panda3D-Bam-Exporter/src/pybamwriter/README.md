This is a set of classes useful for writing Bam files and streams from Python.

Requires Python 3.

Bam specification:
https://www.panda3d.org/manual/index.php/Dev:Bam_Format
